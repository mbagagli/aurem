__name__ = "aurem"
__author__ = "Matteo Bagagli"
__version__ = "1.1.0"
__date__ = "09.2021"
